import telebot
import psycopg2
import datetime
from datetime import datetime
from telebot import types

bot = telebot.TeleBot('2136821386:AAHLQpetT5zt0TeHAFOXywerTmvPFR_VYfE')

@bot.message_handler(commands=['help']) 
def help_message(message): 
    bot.send_message(message.chat.id, 'Привет, я помощник бота. 1. Базовые команды бота: \n/start-начать работу бота \n/help-командный помощник \n/button- вызов кнопки бота') 
 
@bot.message_handler(commands=['start']) 
def start_message(message): 
    bot.send_message(message.chat.id, 'Привет, напиши /button ,чтобы узнать расписание') 
 
@bot.message_handler(commands=['button']) 
def button_message(message): 
    markup=types.ReplyKeyboardMarkup(resize_keyboard=True) 
    btn1 = types.KeyboardButton('Расписание пар на неделю') 
    
    btn8 = types.KeyboardButton('На сегодня') 
    btn9 = types.KeyboardButton('На завтра') 
    markup.add(btn1) 
    markup.add(btn8) 
    markup.add(btn9) 
    
    bot.send_message(message.chat.id, 'Выберите кнопку', reply_markup=markup) 
 
@bot.message_handler(content_types='text') 
def reply_message(message): 
    if message.text == 'Расписание пар на неделю': 
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True) 
        btn2 = types.KeyboardButton('Понедельник') 
        btn3 = types.KeyboardButton('Вторник') 
        btn4 = types.KeyboardButton('Среда') 
        btn5 = types.KeyboardButton('Четверг') 
        btn6 = types.KeyboardButton('Пятница') 
        btn7 = types.KeyboardButton('Суббота')
         
        markup.add(btn2) 
        markup.add(btn3) 
        markup.add(btn4) 
        markup.add(btn5) 
        markup.add(btn6) 
        markup.add(btn7) 
        
         
        bot.send_message(message.chat.id, 'Выбери день недели', reply_markup=markup) 
         
    if message.text == 'Понедельник': 
        coon=psycopg2.connect(database="raspisanie",user="postgres",password="2002",host="localhost",port="5432") 
        cursor=coon.cursor() 
        cursor.execute("SELECT day, subject,room_numb, start_time FROM timetable WHERE day='понедельник'") 
        records=cursor.fetchall() 
        result='' 
        for arr in records: 
            for word in arr: 
                result+=str(word) 
                result+='\n' 
        bot.send_message(message.chat.id, result)     
    if message.text == 'Вторник': 
        coon=psycopg2.connect(database="raspisanie",user="postgres",password="2002",host="localhost",port="5432") 
        cursor=coon.cursor() 
        cursor.execute("SELECT day, subject,room_numb, start_time FROM timetable WHERE day='вторник'") 
        records=cursor.fetchall() 
        result='' 
        for arr in records: 
            for word in arr: 
                result+=str(word) 
                result+='\n' 
        bot.send_message(message.chat.id, result)   
    if message.text == 'Среда': 
        coon=psycopg2.connect(database="raspisanie",user="postgres",password="2002",host="localhost",port="5432") 
        cursor=coon.cursor() 
        cursor.execute("SELECT day,subject,room_numb, start_time FROM timetable WHERE day='среда'") 
        records=cursor.fetchall() 
        result='' 
        for arr in records: 
            for word in arr: 
                result+=str(word) 
                result+='\n' 
        bot.send_message(message.chat.id, result)   
    if message.text == 'Четверг': 
        coon=psycopg2.connect(database="raspisanie",user="postgres",password="2002",host="localhost",port="5432") 
        cursor=coon.cursor() 
        cursor.execute("SELECT day, subject,room_numb, start_time FROM timetable WHERE day='четверг'") 
        records=cursor.fetchall() 
        result='' 
        for arr in records: 
            for word in arr: 
                result+=str(word) 
                result+='\n' 
        bot.send_message(message.chat.id, result)   
    if message.text == 'Пятница': 
        coon=psycopg2.connect(database="raspisanie",user="postgres",password="2002",host="localhost",port="5432") 
        cursor=coon.cursor() 
        cursor.execute("SELECT day, subject,room_numb, start_time FROM timetable WHERE day='пятница'") 
        records=cursor.fetchall() 
        result='' 
        for arr in records: 
            for word in arr: 
                result+=str(word) 
                result+='\n' 
        bot.send_message(message.chat.id, result)
    if message.text == 'Суббота': 
        coon=psycopg2.connect(database="raspisanie",user="postgres",password="2002",host="localhost",port="5432") 
        cursor=coon.cursor() 
        cursor.execute("SELECT day, subject,room_numb, start_time FROM timetable WHERE day='суббота'") 
        records=cursor.fetchall() 
        result='' 
        for arr in records: 
            for word in arr: 
                result+=str(word) 
                result+='\n' 
        bot.send_message(message.chat.id, result)  
    if message.text == 'На сегодня': 
        today=datetime.today().weekday() 
        if today==6: 
            bot.send_message(message.chat.id, 'Сегодня выходной') 
        else: 
            days= ['понедельник','вторник','среда','четверг','пятница','суббота','воскресенье'] 
            seg=str(days[today]) 
            bot.send_message(message.chat.id, seg) 
            coon=psycopg2.connect(database="raspisanie",user="postgres",password="2002",host="localhost",port="5432") 
            cursor=coon.cursor() 
            cursor.execute("SELECT day, subject,room_numb, start_time FROM timetable WHERE day=%s",[seg]) 
            records=cursor.fetchall() 
            result='' 
            for arr in records: 
                for word in arr: 
                    result+=str(word) 
                    result+='\n' 
            bot.send_message(message.chat.id, result)  
             
    if message.text == 'На завтра': 
        today=datetime.today().weekday()+1 
        if today==7: 
            today=0 
        days= ['понедельник','вторник','среда','четверг','пятница','суббота','воскресенье'] 
        seg=str(days[today]) 
        bot.send_message(message.chat.id, seg) 
        coon=psycopg2.connect(database="raspisanie",user="postgres",password="2002",host="localhost",port="5432") 
        cursor=coon.cursor() 
        cursor.execute("SELECT day, subject,room_numb, start_time FROM timetable WHERE day=%s",[seg]) 
        records=cursor.fetchall() 
        result='' 
        for arr in records: 
            for word in arr: 
                result+=str(word) 
                result+='\n' 
        bot.send_message(message.chat.id, result)  
          
    
             
 
bot.infinity_polling()